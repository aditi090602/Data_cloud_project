export const TrendData= [
    {
      name: "TECH",
      shares: 97,
    },
    {
      name: "SPACEX",
      shares: 80.5,
    },
    {
      name: "TESLA",
      shares: 75.5,
    },
    {
      name: "SCIENCE",
      shares: 72,
    },
   
  ];
  