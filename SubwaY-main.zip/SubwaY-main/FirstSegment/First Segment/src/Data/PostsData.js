import postPic1 from '../img/postpic1.jpg'
import postPic2 from '../img/postpic2.jpg'
import postPic3 from '../img/postpic3.jpg'


export const PostsData = [
    {
        img: postPic1,
        name: 'Elon Musk',
        desc: "Happy New Year all friends! #2023",
        likes: "7.2M",
        liked: true
    },
    {
        img: postPic2,
        name: 'Elon Musk',
        desc: "Party time :)",
        likes: "2.3M",
        liked: false

    },
    {
        img:postPic3,
        name: "Elon Musk",
        desc: "At Archery Festival",
        likes: "8M",
        liked: false
    }
]