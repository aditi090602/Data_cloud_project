import img1 from "../img/img1.png";
import img2 from "../img/img2.png";
import img3 from "../img/img3.png";
import img4 from "../img/img4.png";

export const Followers = [
  { name: "Jeff Bezos", username: "JeffBezos", img: img1 },
  { name: "Mark Zuckerberg", username: "MarkZuckerberg", img: img2 },
  { name: "Shantanu Narayen", username: "ShantanuNarayen", img: img3 },
  { name: "Satya Nadella", username: "SatyaNadella", img: img4 },
];